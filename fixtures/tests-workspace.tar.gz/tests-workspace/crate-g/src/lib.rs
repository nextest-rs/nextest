// Copyright (c) The nextest Contributors
// SPDX-License-Identifier: MIT OR Apache-2.0

#[cfg(test)]
mod tests {
    #[test]
    fn test() {}
}
